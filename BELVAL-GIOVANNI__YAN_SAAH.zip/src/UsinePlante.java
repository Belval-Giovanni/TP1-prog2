public class UsinePlante extends Usine{
    

    // metode utile :

    public Plante creerPlante(){
        return new Plante(this.nomEspece,this.tableau);
    }

    //______________________________________________

}
