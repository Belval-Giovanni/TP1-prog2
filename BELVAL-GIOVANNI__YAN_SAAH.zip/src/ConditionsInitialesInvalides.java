public final class ConditionsInitialesInvalides extends Exception {
    public ConditionsInitialesInvalides(String message) {
        super(message);
    }

    public ConditionsInitialesInvalides(String message, Throwable cause) {
        super(message, cause);
    }
}
